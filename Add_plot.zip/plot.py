import numpy as np
import matplotlib.pyplot as plt

f = open("plot","r")

lines = f.readlines()

iteration = []
epoch = []
error_v = []
perplexity = []

for line in lines:
	x = line.split(',')
	epoch.append(x[0])
	error_v.append(x[1])
	perplexity.append(x[2])

### plot chart............
plt.plot([i for i in iteration], error_v)
plt.title('Training Loss')
plt.xlabel('No. of Iterations --->')
plt.ylabel('Loss')
plt.savefig('losses.png')
plt.close()

plt.plot([i for i in iteration], perplixty_plot)
plt.title('Training Perplexity')
plt.xlabel('No. of Iterations --->')
plt.ylabel('Perplexity')
plt.savefig('ppl.png')
plt.close()
